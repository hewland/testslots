<?php

namespace Wainwright\CasinoDogOperatorApi;

class CasinoDogOperatorApi
{
}
