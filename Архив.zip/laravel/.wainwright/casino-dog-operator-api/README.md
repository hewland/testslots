## Operator API package
API package to communicate with master api for operators/casino's.